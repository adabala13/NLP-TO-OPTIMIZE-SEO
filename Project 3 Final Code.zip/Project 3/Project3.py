import requests
import re
from bs4 import BeautifulSoup
from collections import Counter
from googlesearch import search
import spacy
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
import nltk


nltk.download("stopwords")
stop_words = set(stopwords.words("english"))
stemmer = PorterStemmer()

def extract_keywords_nlp(text):
    alphanumeric = re.compile(r'\w+') # match alphabetic characters
    words = word_tokenize(text) # tokenizing the text
    stemmer = PorterStemmer()
    stop_words = set(stopwords.words('english')) # stop words
    filtered_words = [stemmer.stem(word) for word in words if word.lower() not in stop_words and alphanumeric.match(word)] # filtering the words
    keyword_count = Counter(filtered_words) # keywords counted
    sorted_keywords = sorted(keyword_count.items(), key=lambda x: x[1], reverse=True) # sort keywords
    return sorted_keywords # returns the sorted keywords

def calculate_seo_score_nlp(url, keyword):
    response = requests.get(url) # get the given url from the user
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser") # BeautifulSoup is used
        page_text = soup.get_text() 
        page_text = ' '.join(word_tokenize(page_text)) # special characters are removed
        keywords = extract_keywords_nlp(page_text) # get keywords from extract_keywords_nlp method
        keyword_count = 0
        keyword = stemmer.stem(keyword.lower())# keywords convereted to lower case
        
        for word, count in keywords: # loop is created to check the maching and their count
            stemmed_word = stemmer.stem(word.lower())
            if stemmed_word == keyword:
                keyword_count = count
        return keyword_count, keywords
    else:
        print(f"Failed to retrieve the webpage. Status code: {response.status_code}")
        return None, []

def calculate_seo_score(url, keyword):
    response = requests.get(url) # get the url
    if response.status_code == 200: # checks the url
        soup = BeautifulSoup(response.text, 'html.parser') 
        page_text = soup.get_text() # text is extracted
        keyword_count = Counter(re.findall(r'\b{}\b'.format(re.escape(keyword)), page_text, re.IGNORECASE)) # keywords are counted
        seo_score = keyword_count[keyword] # get the keywords count
        return seo_score, keyword_count# return the keyword count and keywords that are entered by the user
    else:
        print(f"Failed to retrieve the webpage. Status code: {response.status_code}")
        return None, None


def display_top_10_google_results(keyword):
    top_10_results = [] # list is created
    try:
        search_results = search(keyword, num_results=10) # google search is used
        for i, result in enumerate(search_results, start=1): # search the best 10 pages based on the given keyword
            response = requests.get(result)
            if response.status_code == 200:# checks the website
                soup = BeautifulSoup(response.text, 'html.parser')
                page_text = soup.get_text()# extracting the text
                keyword_count = Counter(re.findall(r'\b{}\b'.format(re.escape(keyword)), page_text, re.IGNORECASE)) # keywords
                count = keyword_count[keyword]
                top_10_results.append({'title': result, 'count': count})
            else:
                top_10_results.append({'title': f"Failed to retrieve the webpage (Status code: {response.status_code})", 'count': 0})
    except Exception as e:
        # gets the webpage link and no of keywords present in
        top_10_results.append({'title': f"An error occurred while performing the Google search: {str(e)}", 'count': 0})

    return top_10_results


if __name__ == '__main__':
    url = input("Enter the URL of the blog: ")
    keyword = input("Enter the keyword to search: ")
    seo_score, keyword_count = calculate_seo_score_nlp(url, keyword)

    if seo_score is not None:
        print(f"Number of occurrences of '{keyword}' on the blog: {seo_score}")
        display_top_10_google_results(keyword)
