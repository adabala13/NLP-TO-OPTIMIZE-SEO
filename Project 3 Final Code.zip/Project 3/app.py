from flask import Flask, render_template, request
import requests
from bs4 import BeautifulSoup
import re
from collections import Counter
from googlesearch import search
from Project3 import calculate_seo_score_nlp,display_top_10_google_results,calculate_seo_score

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/results', methods=['POST'])
def results_nlp():
    url = request.form['url']  # user url
    keyword = request.form['keyword']  # keywords from user url
    seo_score, keywords = calculate_seo_score(url, keyword)  # gets the url and keyword
    keyword_count = seo_score
    if seo_score is not None:
        top_10_results = display_top_10_google_results(keyword)  # top 10 results based on given keyword
        return render_template(
            'results.html',
            seo_score=seo_score,
            keyword_count=keyword_count,
            top_10_results=top_10_results,
            keyword=keyword,  # pass the entered keyword to the template
            entered_keyword_count=f"{keyword} count",  # display the entered keyword and count
            keywords=keywords
        )
    else:
        return "An error occurred."

    
def highlight_keywords_in_text(text, keyword): # it highlights the keyword
    highlighted_text = re.sub(r'\b' + re.escape(keyword) + r'\b', f'<span style="background-color: yellow">{keyword}</span>', text, flags=re.IGNORECASE)
    return highlighted_text
    
def format_blog_content(soup, keyword):
    formatted_text = [] # list 

    for element in soup.find_all(): # text content is formated in heading format
        if element.name == 'h1': 
            formatted_text.append(f"<h1>{element.text}</h1>")
        elif element.name == 'h2':
            formatted_text.append(f"<h2>{element.text}</h2>")
        elif element.name == 'p':
            paragraph_text = highlight_keywords_in_text(element.text, keyword)
            formatted_text.append(f"<p>{paragraph_text}</p>")

    formatted_content = ' '.join(formatted_text)
    return formatted_content


def extract_and_display_keywords(soup, keyword):
    page_text = soup.get_text() # get blog text
    page_text = ' '.join(re.findall(r'\b\w+\b', re.sub(r'[^\w\s]', '', page_text))) # removes special characters 
    keyword_count = Counter(re.findall(r'\b{}\b'.format(re.escape(keyword)), page_text, re.IGNORECASE))
    return keyword_count # returns keywords

    
@app.route('/view_blog')
def view_blog():
    blog_url = request.args.get('blog_url')
    keyword = request.args.get('keyword')

    try:
        response = requests.get(blog_url) # gets the user clinked blog text
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser', exclude_encodings=["lxml"])
            formatted_blog_text = format_blog_content(soup, keyword)
            formatted_blog_text = formatted_blog_text.replace('.', ' ').replace(',', ' ') # replaces the comma character eith space
            score, keywords = calculate_seo_score_nlp(blog_url, keyword) #gets the keywords from the calculate_seo_score_nlp function
            keyword_count = extract_and_display_keywords(soup, keyword) # gets the keyword count from extract_and_display_keywords function
            return render_template('blog.html', formatted_blog_text=formatted_blog_text, keyword_count=keyword_count, keywords=keywords)
        else:
            return f"Failed to retrieve the blog. Status code: {response.status_code}"
    except Exception as e:
        return f"An error occurred while fetching the blog: {str(e)}"



if __name__ == '__main__':
    app.run(debug=True)
